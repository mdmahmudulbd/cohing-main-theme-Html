//Password Type Change Code Start
$(document).ready(function () {
    $("#passwordToggle").click(function () {
        var checkClass = $("#passwordToggle i").hasClass('fa-eye-slash');
        var typeCheck = $("#password").attr('type');

        if (checkClass && typeCheck == 'password'){
            $("#password").attr('type','text');
            $("#passwordToggle i").removeClass('fa-eye-slash').addClass('fa-eye');
        }else{
            $("#password").attr('type','password');
            $("#passwordToggle i").removeClass('fa-eye').addClass('fa-eye-slash');
        }
    });
});
//Password Type Change Code End

//Data Table Start
$(document).ready(function() {
    $('#example').DataTable({
        fixedHeader:true
    });
} );
//Data Table End

//Magnific Popup Start
$(document).ready(function() {
    $('.image-link').magnificPopup({
        type:'image',
        gallery:{
            enabled: true,
            navigateByImgClick: true,
            arrowMarkup: '<button title="%title%" type="button" class="mfp-arrow mfp-arrow-%dir%"></button>',
            tCounter: '<span class="mfp-counter">%curr% of %total%</span>',
        },
        mainClass: 'mfp-with-zoom',
        zoom:{
            enabled: true,
            duration: 300,
            easing: 'ease-in-out',
        },
        preloader: true,
        showCloseBtn:true
    });
});
//Magnific Popup End

//Owl Carousel Configuration Start
$(document).ready(function() {
    $('.owl-carousel').owlCarousel({
        navText:['prev','next'],
        autoplay:true,
        loop:true,
        smartSpeed:1000,
        autoplayTimeout:3000,
        autoplayHoverPause:true,
        margin:0,
        center:true,
        responsiveRefreshRate:200,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
                nav:true
            }
        }
    });
} );
//Owl Carousel Configuration End